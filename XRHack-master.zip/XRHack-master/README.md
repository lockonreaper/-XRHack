# XRHack
##XRHack Weekend Hackathon utilizing the Vive Pro with the Valve Index(Knuckles) Controllers to create a Room Scale Escape Room experience.

Built on Unity 2018.6f with the latest Steam VR service & runtimes. Accurate as of 14/7/2019.
----
Worked on by Zhen Wei, Chuan Hao and Haikel

Hardware 


<img src="https://i.imgur.com/tWndNBP.jpg">
